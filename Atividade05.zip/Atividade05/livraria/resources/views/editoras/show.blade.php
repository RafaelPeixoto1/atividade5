ID:{{$editora->id_editora}}<br>
Designação:{{$editora->nome}}<br>
Observações:{{$editora->morada}}