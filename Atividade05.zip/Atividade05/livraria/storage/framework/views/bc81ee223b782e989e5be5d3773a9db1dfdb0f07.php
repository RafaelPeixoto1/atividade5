<ul>
<?php $__currentLoopData = $editoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>Nome: <?php echo e($editora->nome); ?></li>
<li>Codigo: <?php echo e($editora->id_editora); ?></li>
    <li>Morada:  <?php echo e($editora->morada); ?></li><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($editoras->render()); ?>

<?php $__currentLoopData = $editoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="<?php echo e(route('editoras.show',['id'=>$editora->id_editora])); ?>">
    <?php echo e($editora->nome); ?>

    </a>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\Atividade03\livraria\resources\views/editoras/index.blade.php ENDPATH**/ ?>