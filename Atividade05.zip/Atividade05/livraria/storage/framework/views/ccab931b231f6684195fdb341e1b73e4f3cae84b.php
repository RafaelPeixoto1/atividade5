ID:<?php echo e($livro->idl); ?><br>
Título:<?php echo e($livro->titulo); ?><br>
Idioma:<?php echo e($livro->idioma); ?><?php /**PATH D:\Projeto2\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>