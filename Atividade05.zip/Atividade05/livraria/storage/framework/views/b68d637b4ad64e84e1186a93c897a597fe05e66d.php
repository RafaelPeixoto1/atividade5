<ul>
<?php $__currentLoopData = $livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>Titulo: <?php echo e($livro->titulo); ?></li>
<li>Codigo: <?php echo e($livro->idl); ?></li>
    <li>Idioma:  <?php echo e($livro->idioma); ?></li><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($livros->render()); ?>

<?php $__currentLoopData = $livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="<?php echo e(route('livros.show',['id'=>$livro->idl])); ?>">
    <?php echo e($livro->titulo); ?>

    </a>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\Projeto2\livraria\resources\views/livros/index.blade.php ENDPATH**/ ?>